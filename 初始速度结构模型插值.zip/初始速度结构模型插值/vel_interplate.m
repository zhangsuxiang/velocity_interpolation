% -------------------------------------------------------------------------
% velocity_interpolation.m   (author: zhangsuxiang)
% -------------------------------------------------------------------------
% Purpose :
%   1)  Interpolate 1‑D Vp & Vs depth profiles from a coarse grid (e.g. 5–10 km)
%       to a finer user‑specified depth grid (e.g. 2 km or 3 km spacing).
%   2)  Export an ASCII file with three columns:
%           [ depth(km)   Vp(km/s)   Vs(km/s) ]
%   3)  Reproduce the step‑like velocity–depth plot shown in the example figure.
%
% Rationale for interpolation method
% ----------------------------------
%   • Velocities generally increase monotonically with depth.  A shape‑preserving
%     Piecewise Cubic Hermite interpolant (PCHIP) maintains monotonicity and
%     avoids the overshoot artefacts common to classical cubic splines.
%
% Usage -------------------------------------------------------------------
%   1) Prepare input vectors (column or row) in km / km s⁻¹ units:
%          depth_in  – depth samples of the original model  [nz × 1]
%          Vp_in     – P‑wave velocities corresponding to depth_in
%          Vs_in     – S‑wave velocities corresponding to depth_in
%   2) Run this script (or call the core function below from your own code).
%
% Output
%   • velocity_model_interp.txt  – tab‑separated text file (depth, Vp, Vs)
%   • Figure 1 – step plot identical in style to the provided reference.
% -------------------------------------------------------------------------

%% --------------------------- USER PARAMETERS --------------------------- %%
clear all;close all;clc;
% Example input (replace with your own data or load from file)
prevel= load('速度结构.txt');
depth_in = prevel(:,1);           % km – coarse grid every 5 km
Vp_in    = prevel(:,2) ;   % km/s (dummy)
Vs_in    = prevel(:,3);                              % km/s (dummy)

% Target depth grid (km).  Example: 2‑km spacing.
depth_out = [0,2,5,8,10,12,14,16,18,20,25,30,40]';

% Output filename
out_file = 'velocity_model_interp.txt';

%% -------------------- INTERPOLATION (PCHIP / MONOTONE) ----------------- %%

% Ensure column vectors
[depth_in , sort_idx] = sort(depth_in(:));
Vp_in = Vp_in(sort_idx(:));
Vs_in = Vs_in(sort_idx(:));

depth_out = depth_out(:);

% Check monotonicity of depth_in
if any(diff(depth_in) <= 0)
    error('depth_in must be strictly increasing.');
end

% Piecewise Cubic Hermite Interpolation to preserve monotonicity
Vp_out = interp1(depth_in, Vp_in, depth_out, 'pchip');
Vs_out = interp1(depth_in, Vs_in, depth_out, 'pchip');

%% ------------------------- EXPORT INTERPOLATED MODEL ------------------- %%

data_out = [depth_out Vp_out Vs_out];

writematrix(data_out, out_file, 'Delimiter', '\t');
fprintf('\nInterpolated model written to %s\n', out_file);

%% ------------------------- PLOT FOR VERIFICATION ----------------------- %%

figure('Color','w'); clf; hold on;

% Draw custom stair curves -------------------------------------------------
for k = 1:numel(depth_out)-1
    % Vertical segments
    plot([Vp_out(k) Vp_out(k)], [depth_out(k) depth_out(k+1)], 'b', 'LineWidth',1.5);
    plot([Vs_out(k) Vs_out(k)], [depth_out(k) depth_out(k+1)], 'r', 'LineWidth',1.5);

    % Horizontal segments except at bottom depth
    if k < numel(depth_out)-1
        plot([Vp_out(k) Vp_out(k+1)], [depth_out(k+1) depth_out(k+1)], 'b', 'LineWidth',1.5);
        plot([Vs_out(k) Vs_out(k+1)], [depth_out(k+1) depth_out(k+1)], 'r', 'LineWidth',1.5);
    end
end

% Axis & cosmetic settings -------------------------------------------------
set(gca,'YDir','reverse', 'LineWidth',1.5, 'FontSize',12, ...
         'Box','on', 'TickDir','out', 'Color','none');
xlabel('Velocity(km/s)','FontSize',14);
ylabel('Depth(km)',    'FontSize',14);
xlim([2 9]);
ylim([min(depth_out) max(depth_out)]);

% Legend (lines only) ------------------------------------------------------
plot(nan,nan,'b','LineWidth',1.5);
plot(nan,nan,'r','LineWidth',1.5);
legend({'Vp','Vs'}, 'Location','southwest', 'FontSize',12, 'Box','off');

drawnow;
%% --------------------------- END OF SCRIPT ----------------------------- %%

% Note:  For batch processing multiple 1‑D profiles (e.g., each (x,y) cell
%        in a 3‑D model), wrap the interpolation section in a loop over the
%        horizontal indices and store results into a 3‑D array.
